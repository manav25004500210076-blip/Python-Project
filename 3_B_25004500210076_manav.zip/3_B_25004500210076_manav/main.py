"""PTMAE: Pure Python Transactional Micro-Banking & Audit Engine.

Student: Manav | Roll No.: 36 | Semester: 3 | Division: B
Enrollment Number: 25004500210076

The program follows the supplied SRS and uses only Python built-ins plus
 datetime. It is a learning demonstration, not a real banking system.
"""
from datetime import datetime


# ============================== CUSTOM ERRORS ===============================
class BaseSystemError(Exception):
    """Base exception for expected PTMAE errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when a database record is invalid or cannot be updated."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a value exceeds an allowed account boundary."""


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot complete a settlement."""


# ============================== UNIT 1 ======================================
def compound_interest(principal, annual_rate, years):
    """Calculate annual compound interest using arithmetic and a loop."""
    if principal < 0 or annual_rate < 0 or years < 0:
        raise ValueError("Principal, rate, and years must be non-negative.")
    amount = principal
    year = 0
    while year < int(years):
        amount = amount + amount * annual_rate / 100
        year += 1
    return amount - principal


def calculate_penalty(base_fee, days_late):
    """Calculate a penalty that increases once for each seven-day period."""
    if base_fee < 0 or days_late < 0:
        raise ValueError("Fee and days late must be non-negative.")
    total = 0
    day = 0
    while day < int(days_late):
        total += base_fee * (1 + day // 7)
        day += 1
    return total


def trajectory_guard(starting_balance, transactions, safety_threshold=0):
    """Apply transactions and halt on STOP or when balance is below threshold."""
    balance = starting_balance
    for transaction in transactions:
        if transaction == "STOP" or balance < safety_threshold:
            print("Trajectory guard: sequence halted.")
            break
        if isinstance(transaction, (int, float)):
            balance += transaction
    return balance


def unit_one_menu():
    """Offer interactive banking calculations using nested while loops."""
    while True:
        print("\n-- Banking calculations --")
        print("1. Compound interest  2. Penalty fee  3. Guard demo  0. Back")
        choice = input("Choice: ").strip()
        if choice == "0":
            break
        if choice == "1":
            try:
                p = float(input("Principal: "))
                rate = float(input("Annual rate (%): "))
                years = int(input("Years: "))
                print("Interest:", format(compound_interest(p, rate, years), ".2f"))
            except ValueError as error:
                print("Invalid number:", error)
        elif choice == "2":
            try:
                fee = float(input("Base daily fee: "))
                days = int(input("Days late: "))
                print("Penalty:", format(calculate_penalty(fee, days), ".2f"))
            except ValueError as error:
                print("Invalid number:", error)
        elif choice == "3":
            print("Final balance:", trajectory_guard(1200, [100, -150, -1200, 500], 100))
            print("STOP example:", trajectory_guard(1200, [100, "STOP", 500], 100))
        else:
            print("Invalid choice. Please try again.")


# ============================== UNIT 2 ======================================
def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Manually parse one delimited line; quoted delimiters and doubled quotes work."""
    fields = []
    current = []
    in_quotes = False
    index = 0
    while index < len(line):
        character = line[index]
        if character == quote_char:
            if in_quotes and index + 1 < len(line) and line[index + 1] == quote_char:
                current.append(quote_char)
                index += 1
            else:
                in_quotes = not in_quotes
        elif character == delimiter and not in_quotes:
            fields.append("".join(current).strip())
            current = []
        else:
            current.append(character)
        index += 1
    if in_quotes:
        raise CorruptedRecordError("Unclosed quote in log line.")
    fields.append("".join(current).strip())
    return fields


def create_audit_filter(threshold):
    """Return a closure that accepts records meeting threshold and counts checks."""
    audited_count = 0

    def validate(amount):
        nonlocal audited_count
        audited_count += 1
        return isinstance(amount, (int, float)) and amount >= threshold

    def count():
        """Return how many records this particular filter checked."""
        return audited_count

    validate.audit_count = count
    return validate


def build_position_filters(number_of_columns):
    """Build lambda filters with k=k to prevent late binding."""
    return [
        (lambda row, k=k: k < len(row) and is_positive_number(row[k]))
        for k in range(number_of_columns)
    ]


def is_positive_number(value):
    """Return True if value can be converted to a positive number."""
    try:
        return float(value) > 0
    except (ValueError, TypeError):
        return False


def append_ledger(message, path="ledger.txt"):
    """Append a timestamped validated event to the ledger file."""
    with open(path, "a", encoding="utf-8") as ledger:
        ledger.write(datetime.now().isoformat(timespec="seconds") + " | " + message + "\n")


# ============================== UNIT 3 ======================================
RAW_DB = {
    "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
    "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})],
}


def build_reverse_index(raw_db):
    """Map every service tag to sorted unique (account_id, branch_id) pairs."""
    return {
        tag: sorted({
            (account_id, branch_id)
            for branch_id, records in raw_db.items()
            for account_id, tags in records
            if tag in tags
        })
        for tag in {tag for records in raw_db.values() for account_id, tags in records for tag in tags}
    }


def is_primitive(value):
    """Identify simple top-level values whose duplicates should be removed."""
    return isinstance(value, (str, int, float, bool, type(None)))


def clean_transaction_queue(data_list):
    """Modify the supplied list in place without replacing the top-level list."""
    for index in range(len(data_list)):
        item = data_list[index]
        if isinstance(item, tuple):
            item = list(item)
            data_list[index] = item
        if isinstance(item, set):
            even_values = {value for value in item if isinstance(value, int) and not isinstance(value, bool) and value % 2 == 0}
            item.difference_update(even_values)
        elif isinstance(item, list):
            item.sort(reverse=True)

    # Remove repeated primitive top-level values by scanning and deleting by index.
    index = 0
    while index < len(data_list):
        current = data_list[index]
        duplicate = False
        if is_primitive(current):
            previous_index = 0
            while previous_index < index:
                previous = data_list[previous_index]
                if is_primitive(previous) and type(previous) is type(current) and previous == current:
                    duplicate = True
                    break
                previous_index += 1
        if duplicate:
            del data_list[index]
        else:
            index += 1
    return data_list


# ============================== UNIT 4 ======================================
def ensure_accounts_file(path="accounts.db"):
    """Create sample records only when the database file is empty or missing."""
    try:
        with open(path, "r", encoding="utf-8") as account_file:
            existing = account_file.read(1)
    except FileNotFoundError:
        existing = ""
    if existing == "":
        with open(path, "w", encoding="utf-8") as account_file:
            account_file.write("Acc101,SAVINGS,5200.00\n")
            account_file.write("Acc102,CURRENT,2500.00\n")
            account_file.write("Acc103,CREDIT,1000.00\n")


def shift_suffix(file_object, suffix_start, delta, original_end):
    """Shift file text in chunks to make room for an in-place record replacement."""
    chunk_size = 256
    if delta > 0:
        read_position = original_end
        while read_position > suffix_start:
            chunk_start = read_position - chunk_size
            if chunk_start < suffix_start:
                chunk_start = suffix_start
            file_object.seek(chunk_start)
            chunk = file_object.read(read_position - chunk_start)
            file_object.seek(chunk_start + delta)
            file_object.write(chunk)
            read_position = chunk_start
    elif delta < 0:
        read_position = suffix_start
        while read_position < original_end:
            file_object.seek(read_position)
            chunk = file_object.read(chunk_size)
            if chunk == "":
                break
            file_object.seek(read_position + delta)
            file_object.write(chunk)
            read_position += len(chunk)


def update_account_record(account_id, new_balance, path="accounts.db"):
    """Validate records and update one balance in r+ mode without rewriting the file."""
    if not isinstance(new_balance, (int, float)) or new_balance < 0:
        raise OutOfBoundsError("New balance must be a non-negative number.")
    ensure_accounts_file(path)
    processed = 0
    rejected = 0
    found = False
    try:
        with open(path, "r+", encoding="utf-8", newline="") as account_file:
            line_number = 0
            while True:
                record_start = account_file.tell()
                line = account_file.readline()
                if line == "":
                    break
                line_number += 1
                try:
                    fields = parse_raw_log_line(line.rstrip("\n"))
                    if len(fields) != 3 or not fields[0] or fields[1] not in ("SAVINGS", "CURRENT", "CREDIT"):
                        raise CorruptedRecordError("Expected ID,known account type,balance.")
                    old_balance = float(fields[2])
                    if old_balance < 0:
                        raise CorruptedRecordError("Balance cannot be negative.")
                except (ValueError, CorruptedRecordError):
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as error_log:
                        error_log.write("Line " + str(line_number) + ": " + line)
                    continue
                else:
                    processed += 1
                finally:
                    # Per-record handling continues after malformed lines.
                    pass

                if fields[0] == account_id:
                    replacement = fields[0] + "," + fields[1] + "," + format(new_balance, ".2f") + "\n"
                    old_end = account_file.tell()
                    original_end = account_file.seek(0, 2)
                    old_length = old_end - record_start
                    delta = len(replacement) - old_length
                    shift_suffix(account_file, old_end, delta, original_end)
                    account_file.seek(record_start)
                    account_file.write(replacement)
                    account_file.truncate(original_end + delta)
                    found = True
                    append_ledger("Updated " + account_id + " balance to " + format(new_balance, ".2f"))
                    break
    except OSError as error:
        raise CorruptedRecordError("File operation failed: " + str(error))
    finally:
        print("Valid records processed:", processed)
        print("Rejected records:", rejected)
    if not found:
        raise CorruptedRecordError("Account ID not found: " + account_id)
    return True


def show_accounts(path="accounts.db"):
    """Display valid account rows and log any malformed records."""
    ensure_accounts_file(path)
    print("\nAccount records")
    with open(path, "r", encoding="utf-8") as account_file:
        for line_number, line in enumerate(account_file, 1):
            try:
                fields = parse_raw_log_line(line.rstrip("\n"))
                if len(fields) != 3 or fields[1] not in ("SAVINGS", "CURRENT", "CREDIT"):
                    raise CorruptedRecordError("Invalid record fields.")
                balance = float(fields[2])
                if balance < 0:
                    raise CorruptedRecordError("Negative balance.")
                print(fields[0], "|", fields[1], "|", format(balance, ".2f"))
            except (ValueError, CorruptedRecordError) as error:
                with open("corrupted.log", "a", encoding="utf-8") as error_log:
                    error_log.write("Line " + str(line_number) + ": " + line)
                print("Skipped line", line_number, "-", error)


# ============================== UNIT 5 ======================================
class Account:
    """Base account with private balance, protected ID and shared object count."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        if not isinstance(account_id, str) or account_id == "":
            raise TypeError("Account ID must be a non-empty string.")
        if not isinstance(balance, (int, float)) or isinstance(balance, bool) or balance < 0:
            raise OutOfBoundsError("Opening balance must be non-negative numeric data.")
        self._account_id = account_id
        self.__balance = float(balance)
        Account.total_accounts += 1

    def get_balance(self):
        """Return the current balance."""
        return self.__balance

    def set_balance(self, amount):
        """Set a valid non-negative numeric balance."""
        if not isinstance(amount, (int, float)) or isinstance(amount, bool):
            raise TypeError("Balance must be numeric.")
        if amount < 0:
            raise OutOfBoundsError("Balance cannot be negative.")
        self.__balance = float(amount)

    def process_settlement(self, amount):
        """Define the settlement interface for subclasses."""
        raise NotImplementedError("Subclass must define process_settlement().")

    def __str__(self):
        return self._account_id + " balance=" + format(self.get_balance(), ".2f")


class SavingsAccount(Account):
    """Savings account that keeps at least 1000 units in the account."""
    def process_settlement(self, amount):
        validate_amount(amount)
        remaining = self.get_balance() - amount
        if remaining < 1000:
            raise InsufficientBalanceError("Savings account must retain 1000.00.")
        self.set_balance(remaining)


class CurrentAccount(Account):
    """Current account that can use its private overdraft limit."""
    def __init__(self, account_id, balance, overdraft_limit=500):
        super().__init__(account_id, balance)
        if overdraft_limit < 0:
            raise OutOfBoundsError("Overdraft limit cannot be negative.")
        self.__overdraft_limit = float(overdraft_limit)
        self.__overdraft_used = 0.0

    def process_settlement(self, amount):
        validate_amount(amount)
        available_balance = self.get_balance()
        extra_needed = amount - available_balance
        if extra_needed < 0:
            extra_needed = 0.0
        if self.__overdraft_used + extra_needed > self.__overdraft_limit:
            raise InsufficientBalanceError("Current account overdraft limit exceeded.")
        if amount <= available_balance:
            self.set_balance(available_balance - amount)
        else:
            self.set_balance(0.0)
            self.__overdraft_used += extra_needed

    def get_overdraft_used(self):
        """Return the amount currently used from the overdraft limit."""
        return self.__overdraft_used


class CreditAccount(Account):
    """Credit account applies a 2.5 percent surcharge to each settlement."""
    def __init__(self, account_id, balance, credit_limit=5000):
        super().__init__(account_id, balance)
        if credit_limit < 0:
            raise OutOfBoundsError("Credit limit cannot be negative.")
        self.__credit_limit = float(credit_limit)
        self.__credit_used = 0.0

    def process_settlement(self, amount):
        validate_amount(amount)
        charged_amount = amount + amount * 2.5 / 100
        if self.__credit_used + charged_amount > self.__credit_limit:
            raise OutOfBoundsError("Credit limit exceeded.")
        self.__credit_used += charged_amount

    def get_credit_used(self):
        """Return the used portion of the credit limit."""
        return self.__credit_used


def validate_amount(amount):
    """Validate a positive settlement amount."""
    if not isinstance(amount, (int, float)) or isinstance(amount, bool):
        raise TypeError("Settlement amount must be numeric.")
    if amount <= 0:
        raise OutOfBoundsError("Settlement amount must be greater than zero.")


def execute_batch_settlement(account_list, transaction_amount):
    """Run each account settlement independently and report successes/failures."""
    successes = 0
    failures = 0
    for account in account_list:
        try:
            account.process_settlement(transaction_amount)
        except (BaseSystemError, TypeError, ValueError) as error:
            failures += 1
            print("FAILED", account._account_id, "-", error)
            append_ledger("Settlement failed for " + account._account_id + ": " + str(error))
        else:
            successes += 1
            print("SUCCESS", account._account_id)
            append_ledger("Settlement succeeded for " + account._account_id + ": " + format(transaction_amount, ".2f"))
    print("Batch summary: successes =", successes, ", failures =", failures)
    return successes, failures


# ============================== DEMONSTRATION ===============================
def run_demonstration():
    """Exercise the requirements from Units 1 through 5."""
    print("\nSTUDENT: Manav | ROLL NO: 36 | SEMESTER: 3 | DIVISION: B")
    print("\nUNIT 1 - CALCULATIONS AND TRAJECTORY GUARDS")
    print("Interest on 10000 at 5% for 2 years:", format(compound_interest(10000, 5, 2), ".2f"))
    print("Penalty for 10 days at 20 per day:", format(calculate_penalty(20, 10), ".2f"))
    print("Guard safety example:", trajectory_guard(1200, [100, -1300, 50], 100))
    print("Guard stop example:", trajectory_guard(1200, [100, "STOP", 50], 100))

    print("\nUNIT 2 - MANUAL PARSER, CLOSURE, LAMBDAS")
    examples = ['Acc101,"Savings, Premium",5200', 'Acc102,"Member ""Gold""",2500', 'Acc103,CREDIT,']
    for example in examples:
        print(example, "=>", parse_raw_log_line(example))
    audit_filter = create_audit_filter(500)
    print("Audit decisions:", [audit_filter(amount) for amount in (100, 500, 900)])
    print("Audit count:", audit_filter.audit_count())
    positional_filters = build_position_filters(3)
    print("Filter column 0:", positional_filters[0](["700", "-2", "5"]))
    print("Filter column 2:", positional_filters[2](["700", "-2", "5"]))

    print("\nUNIT 3 - REVERSE INDEX AND IN-PLACE QUEUE")
    print("Reverse index:", build_reverse_index(RAW_DB))
    queue = [7, 7, (3, 1), {2, 3, 4, 5}, [2, 8, 4], "OK", "OK", 9]
    old_identity = id(queue)
    print("Before:", queue)
    clean_transaction_queue(queue)
    print("After: ", queue)
    print("Same list object:", old_identity == id(queue))

    print("\nUNIT 4 - FILE UPDATES AND ERROR LOGGING")
    show_accounts()
    try:
        update_account_record("Acc101", 5250.0)
    except BaseSystemError as error:
        print("Account update issue:", error)
    show_accounts()

    print("\nUNIT 5 - ENCAPSULATION AND POLYMORPHISM")
    accounts = [SavingsAccount("SAV201", 4000), CurrentAccount("CUR201", 300), CreditAccount("CRD201", 0, 2000)]
    print("Account count:", Account.total_accounts)
    print("Exception hierarchy checks:",
          issubclass(CorruptedRecordError, BaseSystemError),
          issubclass(OutOfBoundsError, BaseSystemError),
          issubclass(InsufficientBalanceError, BaseSystemError))
    print("Correct mangled balance access:", accounts[0]._Account__balance)
    try:
        print(accounts[0].__balance)
    except AttributeError:
        print("Direct __balance access fails as expected (name mangling).")
    execute_batch_settlement(accounts, 800)
    for account in accounts:
        print(account)
    print("Current overdraft used:", format(accounts[1].get_overdraft_used(), ".2f"))
    print("Credit used:", format(accounts[2].get_credit_used(), ".2f"))


def main():
    """Run an interactive command loop until the user explicitly exits."""
    while True:
        print("\nPTMAE - PURE PYTHON MICRO-BANKING ENGINE")
        print("1. Run complete requirements demonstration")
        print("2. Show account records")
        print("3. Update an account balance")
        print("4. Banking calculations")
        print("0. Exit")
        command = input("Enter command: ").strip()
        if command == "0":
            print("Goodbye.")
            break
        elif command == "1":
            try:
                run_demonstration()
            except (BaseSystemError, ValueError, OSError) as error:
                print("Demonstration handled an issue:", error)
        elif command == "2":
            try:
                show_accounts()
            except OSError as error:
                print("Could not read account file:", error)
        elif command == "3":
            account_id = input("Account ID: ").strip()
            try:
                amount = float(input("New balance: "))
                update_account_record(account_id, amount)
            except (BaseSystemError, ValueError, OSError) as error:
                print("Update failed:", error)
        elif command == "4":
            unit_one_menu()
        else:
            print("Invalid command. Select 0, 1, 2, 3 or 4.")


if __name__ == "__main__":
    main()
