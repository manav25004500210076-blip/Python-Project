# PTMAE — Project Documentation

## Student information
- **Name:** Manav
- **Roll number:** 36
- **Semester:** 3
- **Division:** B
- **Enrollment number:** 25004500210076
- **Project:** Pure Python Transactional Micro-Banking & Audit Engine (PTMAE)

## 1. Project overview
PTMAE is a command-line banking learning project based on the supplied Software Requirements Specification (SRS). It demonstrates banking calculations, manual log parsing, closures, lambda functions, reverse indexing, in-place list processing, text-file updates, custom exceptions, and object-oriented settlement. It is not a real banking product and does not use a database engine or a graphical interface.

## 2. How to run
1. Install Python 3.
2. Keep `main.py` and `documentation.md` in the assignment folder.
3. Open a terminal in that folder and run `python main.py`.
4. Choose `1` to run the complete demonstration, `2` to view account records, `3` to update a balance, `4` for the calculations menu, or `0` to exit.

The program creates `accounts.db` when it is first needed. It may also create `ledger.txt` and `corrupted.log` at runtime. These are generated data/log files; the initial assignment folder should contain only the two required submission files.

## 3. Architecture diagram

```text
                         +-------------------+
                         | main() CLI loop   |
                         +---------+---------+
                                   |
              +--------------------+--------------------+
              |                    |                    |
       +------v------+      +------v------+      +------v------+
       | Unit 1      |      | Unit 2      |      | Unit 3      |
       | Calculations|      | Parser and  |      | Reverse     |
       | and guards  |      | closures    |      | index/queue |
       +-------------+      +-------------+      +-------------+
              |                    |                    |
              +--------------------+--------------------+
                                   |
                         +---------v---------+
                         | Unit 4: accounts  |
                         | file + audit logs |
                         +---------+---------+
                                   |
                         +---------v---------+
                         | Unit 5: Account   |
                         | subclasses and    |
                         | batch settlement  |
                         +-------------------+
```

## 4. Unit-wise implementation

### Unit 1 — State control and trajectory guards
- `compound_interest()` calculates annual compound interest using a loop and arithmetic operators.
- `calculate_penalty()` calculates a fee that increases after each seven-day period.
- `trajectory_guard()` stops processing when a `STOP` marker is encountered or the balance falls below the safety threshold.
- `unit_one_menu()` is an interactive nested-loop menu and handles invalid numeric input.

### Unit 2 — Native parser and closure mechanics
- `parse_raw_log_line()` manually scans the input character by character. It supports delimiters inside quoted fields, doubled quote characters, empty fields, and a trailing delimiter. It does not use the `csv` module or `str.split()`/`str.replace()`.
- `create_audit_filter()` returns a nested validation function. Its `nonlocal` counter increases each time the filter is called, and separate filters have separate counters.
- `build_position_filters()` creates lambda functions with `k=k`, so each lambda keeps its own column index instead of using the final loop value.
- `append_ledger()` appends a timestamped event to `ledger.txt`.

### Unit 3 — Data inversion and in-place processing
- `build_reverse_index()` uses nested comprehensions to map each service tag to a sorted list of unique `(account_id, branch_id)` pairs.
- `clean_transaction_queue()` modifies the same top-level list object. It converts tuple entries to lists, removes even integer IDs from sets, sorts embedded lists in descending order, and removes repeated primitive top-level values while keeping the first occurrence.
- The demonstration compares `id(queue)` before and after cleaning to show that the list object is unchanged.

### Unit 4 — Transactional file modifier and error logger
- `update_account_record()` uses `r+` mode to find and update a record in `accounts.db`.
- If a replacement record changes length, `shift_suffix()` moves the following file content in chunks before the replacement is written. The whole file is not loaded into memory and rewritten.
- Malformed records are skipped and recorded with their line number in `corrupted.log`.
- Accepted updates and settlement outcomes are appended to `ledger.txt`.
- The record-processing code uses `try`, `except`, `else`, and `finally`; the `finally` block prints processed and rejected record counts.

### Unit 5 — Object-oriented and polymorphic engine
- `Account` contains private `__balance`, protected `_account_id`, and class attribute `total_accounts`.
- Public `get_balance()` and `set_balance()` methods validate balance values.
- `SavingsAccount` must retain a minimum balance of 1000.
- `CurrentAccount` tracks usage against its private overdraft limit.
- `CreditAccount` adds a 2.5% surcharge and checks the private credit limit.
- Each subclass overrides `process_settlement()`.
- `execute_batch_settlement()` wraps each account's settlement in its own `try-except`, so one failure does not stop later accounts.
- The demonstration shows name mangling using `_Account__balance` and shows that direct `obj.__balance` access fails.

## 5. State and scope tracking

| State/name | Scope or visibility | Purpose |
|---|---|---|
| `RAW_DB` | Module-level constant | Sample branch/account/service data for reverse indexing |
| `audited_count` | Enclosing function local, accessed with `nonlocal` | Count calls to each audit closure independently |
| `k` | Lambda default argument (`k=k`) | Preserve each lambda's own positional column index |
| `Account.__balance` | Private instance attribute (name-mangled) | Store account balance |
| `Account._account_id` | Protected-style instance attribute | Store account identifier for subclasses |
| `Account.total_accounts` | Class attribute | Count constructed account objects |
| `CurrentAccount.__overdraft_limit` | Private subclass attribute | Set maximum overdraft usage |
| `CurrentAccount.__overdraft_used` | Private subclass attribute | Track current overdraft use |
| `CreditAccount.__credit_limit` | Private subclass attribute | Set maximum credit usage |
| `CreditAccount.__credit_used` | Private subclass attribute | Track credit usage including surcharge |

No global variable is used to pass mutable state into a closure or to repair lambda late binding.

## 6. Custom exception hierarchy

```text
Exception
   |
   +-- BaseSystemError
          |
          +-- CorruptedRecordError
          +-- OutOfBoundsError
          +-- InsufficientBalanceError
```

The demonstration runs `issubclass()` checks for all three specific exceptions.

## 7. Module compliance checklist (Units 1–5)

| SRS requirement area | Implementation/check |
|---|---|
| Unit 1: loops and arithmetic | Compound interest, penalty calculation, nested interactive loops, early-stop guard |
| Unit 2: parser | Manual character-by-character parsing; quoted commas, doubled quotes, empty and trailing fields |
| Unit 2: closure | `create_audit_filter()` uses `nonlocal` and maintains a separate count per closure |
| Unit 2: lambda binding | `build_position_filters()` uses `k=k` |
| Unit 3: comprehensions | Reverse-index dictionary and nested set/list comprehensions |
| Unit 3: in-place list | Mutates the passed list, removes duplicate primitive entries by indexed scanning |
| Unit 4: file handling | Uses `r+`, `seek()`, `tell()`, chunked shifting, `truncate()`, and context managers |
| Unit 4: error logging | Rejected rows go to `corrupted.log`; accepted operations go to `ledger.txt` |
| Unit 4: custom errors | Three subclasses derive from `BaseSystemError` |
| Unit 5: encapsulation | Private balance, protected account ID, getters/setters, name-mangling demonstration |
| Unit 5: inheritance | Three account subclasses call `super().__init__()` |
| Unit 5: polymorphism | Each account type overrides `process_settlement()`; batch isolates failures |
| Imports | Only `datetime` is imported; no third-party packages are used |
| Prohibited shortcuts | No `csv`, `json`, `re`, `math`, `os`, `sys`, `sqlite3`, `pandas`, or `numpy`; parser does not use `split()` or `replace()` |

## 8. Data and log files

| File | Purpose |
|---|---|
| `accounts.db` | Plain-text records in `account_id,account_type,balance` format |
| `ledger.txt` | Timestamped successful updates and settlement results |
| `corrupted.log` | Invalid records with line numbers |

Account types accepted by the program are `SAVINGS`, `CURRENT`, and `CREDIT`. Amounts are represented as non-negative numbers where applicable. Runtime files are generated in the current working directory.

## 9. Suggested test checklist
1. Run the full demonstration and exit with command `0`.
2. Test the parser with a comma inside quotes, a doubled quote, an empty field, and a trailing delimiter.
3. Call an audit filter several times and check its count; create a second filter and verify its count starts independently.
4. Verify that the lambda for column 0 and the lambda for column 2 check different positions.
5. Verify that the queue's `id()` is unchanged after cleaning.
6. Update an account and confirm adjacent records in `accounts.db` remain unchanged.
7. Introduce a malformed account line and confirm it is recorded in `corrupted.log` while processing continues.
8. Run batch settlement with accounts that succeed and fail; verify later accounts are still processed.

## 10. Conclusion
PTMAE combines the Python concepts from Units 1–5 in one command-line program. It demonstrates control flow, arithmetic, manual parsing, closures, comprehensions, in-place data processing, file operations, exception handling, inheritance, encapsulation, and polymorphism in the banking scenario specified by the SRS.
